// See LICENSE.txt for license details
package merl

import chisel3.iotesters.PeekPokeTester

class RV32ITests(c: RV32I) extends PeekPokeTester(c) {
  def rd() = {
//for(i<-0 until 1)
//{
 //   poke(c.io.clock, 1)
	step(1)
 //   poke(c.io.wrData, 9437843L)
   // step(1)
  //  poke(c.io.clock, 1)
 //   poke(c.io.wrData, 13632275L)
//   step(1)
   // poke(c.io.clock, 1)
 //   poke(c.io.wrData, 5444707L)
  //  step(1)
   // poke(c.io.clock, 1)
  //  poke(c.io.wrData, 1079182259L)
  //  step(1)
   // poke(c.io.clock, 1)
  //  poke(c.io.wrData, 6456243L)

//}
 //   poke(c.io.clock, 1)
 //   poke(c.io.wrData, 1998483)
 //   step(1)
 //   poke(c.io.clock, 1)
  //  poke(c.io.wrData, 4262365411L)
 //   step(1)
 //   poke(c.io.clock, 1)
 //   poke(c.io.wrData, 230195)
 //   step(1)
 //   poke(c.io.clock, 1)
 //   poke(c.io.wrData, 31687779L)
  //  step(1)
  //  poke(c.io.clock, 1)
  //  poke(c.io.wrData, 4271894767L)
  //  step(1)


       
}
 
 rd()
 
}
