// See LICENSE.txt for license details
package merl

import chisel3.iotesters.PeekPokeTester

class TopTests(c: Top) extends PeekPokeTester(c) {

    step(1) 
    step(1)
    step(1) 
    step(1)
    step(1) 
    step(1)
    step(1) 
    step(1)
    step(1) 
    step(1)
    step(1)
    step(1) 
    step(1)
    step(1)
    step(1) 
    step(1)
    step(1)
    step(1) 
    step(1)
    step(1)
    step(1) 
    step(1)
}
