# RISCV-Single-Cycle-Core-Chisel
This repository contains the single cycle core implementation of RISC-V ISA on Chisel. \
In this version we have implemented the RV32I base ISA on chisel the core is able to run all instructions of RV32I ISA. \
Except syscall and FENCES instuction. These instructions will be added in later version.
